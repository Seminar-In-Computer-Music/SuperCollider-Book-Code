/*
 * File: CU_PulseLookUpTables_types.h
 *
 * Real-Time Workshop code generated for Simulink model CU_PulseLookUpTables.
 *
 * Model version                        : 1.112
 * Real-Time Workshop file version      : 6.4.1  (R2006a+)  29-Mar-2006
 * Real-Time Workshop file generated on : Fri Jun  9 17:37:55 2006
 * TLC version                          : 6.4 (Jan 31 2006)
 * C source code generated on           : Fri Jun  9 17:37:58 2006
 */

#ifndef _RTW_HEADER_CU_PulseLookUpTables_types_h_
#define _RTW_HEADER_CU_PulseLookUpTables_types_h_

/* Forward declaration for rtModel */
typedef struct RT_MODEL_CU_PulseLookUpTables RT_MODEL_CU_PulseLookUpTables;

#endif                                  /* _RTW_HEADER_CU_PulseLookUpTables_types_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * [EOF]
 */


