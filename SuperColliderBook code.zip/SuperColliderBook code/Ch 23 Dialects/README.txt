READ ME

The SuperCollider Book
Chapter 23. Dialects, Constraints, and Systems within Systems

Extensions and plug-ins are made for SC 3.4, and may not be backwards compatible with future versions of SuperCollider.

Note:	Pokey requires the Bit extension.
	RedXM requires RedPhasor.

In time, newer versions of extensions and plug-ins may be available from the following sites:

Pokey, RedXM, Bit and RedPhasor
	Fredrik Olofsson's website
	http://www.fredrikolofsson.com
	(look for 'code' in the menu)

Infno (aka Infpop)
	Nick Collins' academic website
	http://www.cogs.susx.ac.uk/users/nc81/
	Info on Infno
	http://www.cogs.susx.ac.uk/users/nc81/infno.html

HierSch
	is a Quark, and can be updated via Quarks.gui
	otherwise
	Tom Hall's website
	http://www.ludions.com
	(look for 'code' in the menu)

Controller
	is a Quark, and can be updated via Quarks.gui
	(under its name is rd_ctl)

