
HierSch - Hierarchical Scheduler

(c) 2007-2011 Tom Hall 
GPLv3, http://gnu.org/copyleft/


// Changes log

2011-03-24
TempoClock.default used if no tempoClock supplied
Updated Helpfile

2009-01-22
Changed priority structure from priority 12 to priority 0 always plays.
Updated Helpfile

2008-02-03
help file expanded, priority method name changes
schedAbs, schedStream and schedQuant refactored

2008-01-28
refactored sched and schedBar methods

2007-12-29 
cease method fixed

